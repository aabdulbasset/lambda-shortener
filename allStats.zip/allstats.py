import psycopg2
import json
from urllib.parse import urlparse
import os
dbURL = urlparse(os.environ['DATABASE_URL'])

def all_links(event, context):
    # Connect to the PostgreSQL database
    conn = psycopg2.connect(
        database=dbURL.path[1:],
        user=dbURL.username,
        password=dbURL.password,
        host=dbURL.hostname,
        port=dbURL.port,
        sslmode='require',
    )
    cur = conn.cursor()
    
    # Retrieve the short_code, original_url, number of hits, and last_click time for all URLs
    cur.execute("""
        SELECT urls.shorturl, urls.url, 
               COUNT(url_stats.user_ip) as hits, 
               MAX(url_stats.request_time) as last_click 
        FROM urls 
        LEFT JOIN url_stats ON urls.shorturl = url_stats.url 
        GROUP BY urls.shorturl, urls.url;
    """)
    results = cur.fetchall()
    
    cur.close()
    conn.close()
    
    # Format the results into a list of dictionaries
    data = []
    for row in results:
        link_data = {
            'short_code': row[0],
            'url': row[1],
            'hits': row[2] if row[2] is not None else 0,
            'last_click': str(row[3]) if row[3] is not None else None
        }
        data.append(link_data)
    
    # Return the data as a JSON response
    return {
        'statusCode': 200,
        'body': json.dumps(data),
        'headers': {
            'Content-Type': 'application/json'
        }
    }